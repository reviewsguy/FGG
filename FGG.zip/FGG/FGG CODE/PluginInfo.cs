﻿namespace StupidTemplate
{
    public class PluginInfo
    {
        public const string GUID = "org.iidk.gorillatag.menutemplate";
        public const string Name = "FGG Admin Menu!";
        public const string Description = "For da boyss";
        public const string Version = "1.0.0";
    }
}
