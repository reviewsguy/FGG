using GorillaLocomotion;
using StupidTemplate.Classes;
using UnityEngine;
using UnityEngine.XR;
using static StupidTemplate.Menu.Main;
using StupidTemplate.Notifications;



namespace StupidTemplate.Mods
{
   public class Game
    {
        public static void Close_Game()
        {
        NotifiLib.SendNotification("Bye Bye Game!");
            Application.Quit();
        }

        public static void UncapFPS()
        {
            QualitySettings.vSyncCount = 0;
            Application.targetFrameRate = int.MaxValue;
        }

        public static void FPSBoostIndev()
        {
            QualitySettings.vSyncCount = 0;
            QualitySettings.terrainDetailDensityScale = 1;
            QualitySettings.globalTextureMipmapLimit = 1;
        }
        public static void FPS60()
        {
            Application.targetFrameRate = 60;
            QualitySettings.vSyncCount = 0;

        }

        public static void FPS40()
        {
            Application.targetFrameRate = 40;
            QualitySettings.vSyncCount = 0;
        }

        public static void FPS20()
        {
            Application.targetFrameRate = 20;
            QualitySettings.vSyncCount = 0;
        }

        public static void FPS5()
        {
            Application.targetFrameRate = 5;
            QualitySettings.vSyncCount = 0;
        }
    } 
}